"use client";

import { useState } from "react";
import { signInWithGoogle } from "@/lib/mutations/auth";

export function GoogleSignInButton() {
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleClick() {
    setError(null);
    setPending(true);
    const result = await signInWithGoogle();
    if (!result.ok) {
      setError(result.error);
      setPending(false);
    }
    // On success the browser is navigating away to Google, so we
    // deliberately leave `pending` true — no flash back to enabled.
  }

  return (
    <>
      <button
        type="button"
        className="google-btn"
        onClick={handleClick}
        disabled={pending}
      >
        <svg
          className="google-icon"
          viewBox="0 0 18 18"
          xmlns="http://www.w3.org/2000/svg"
          aria-hidden="true"
        >
          <path
            fill="#4285F4"
            d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.9c1.7-1.57 2.7-3.88 2.7-6.62z"
          />
          <path
            fill="#34A853"
            d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.9-2.26c-.8.54-1.84.86-3.06.86-2.35 0-4.34-1.59-5.05-3.72H.94v2.33A9 9 0 0 0 9 18z"
          />
          <path
            fill="#FBBC05"
            d="M3.95 10.7A5.4 5.4 0 0 1 3.66 9c0-.59.1-1.17.29-1.7V4.97H.94A9 9 0 0 0 0 9c0 1.45.35 2.83.94 4.03l3.01-2.33z"
          />
          <path
            fill="#EA4335"
            d="M9 3.58c1.32 0 2.51.46 3.44 1.35l2.58-2.58C13.46.89 11.43 0 9 0A9 9 0 0 0 .94 4.97l3.01 2.33C4.66 5.17 6.65 3.58 9 3.58z"
          />
        </svg>
        {pending ? "Redirecting to Google…" : "Continue with Google"}
      </button>
      {error && <p className="form-error">{error}</p>}
    </>
  );
}
