"use client";

import { useRouter, usePathname, useSearchParams } from "next/navigation";
import CategorySelector from "@/components/CategorySelector";

type CategoryFilterBarProps = {
  categories: string[];
  activeCategory: string | null;
};

/**
 * Wires CategorySelector (a self-contained, name-string-based component)
 * to the URL's `?category=` search param, so the filter is server-driven,
 * shareable/bookmarkable, and doesn't need its own client-side data fetch.
 * page.tsx (server component) reads the same search param on each request
 * to resolve the category name -> category_id and pass it to get_home_feed.
 */
export default function CategoryFilterBar({
  categories,
  activeCategory,
}: CategoryFilterBarProps) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  const handleChange = (category: string | null) => {
    const params = new URLSearchParams(searchParams.toString());
    if (category) {
      params.set("category", category);
    } else {
      params.delete("category");
    }
    const query = params.toString();
    router.push(query ? `${pathname}?${query}` : pathname);
  };

  return (
    <CategorySelector
      categories={categories}
      activeCategory={activeCategory}
      onChange={handleChange}
    />
  );
}
