'use client';

import { useState } from 'react';

const DEFAULT_CATEGORIES = ['Nightlife', 'Sports', 'Arts and Culture', 'Music'];

interface CategorySelectorProps {
  categories?: string[];
  defaultActive?: string | null;
  /** Pass this + onChange for controlled usage. `null` means no filter (all events). */
  activeCategory?: string | null;
  onChange?: (category: string | null) => void;
}

export default function CategorySelector({
  categories = DEFAULT_CATEGORIES,
  defaultActive = null,
  activeCategory,
  onChange,
}: CategorySelectorProps) {
  const [internalActive, setInternalActive] = useState<string | null>(
    defaultActive
  );

  const isControlled = activeCategory !== undefined;
  const active = isControlled ? activeCategory : internalActive;

  const handleClick = (category: string) => {
    // Clicking the already-active category clears the filter (shows all events).
    // Clicking a different category switches the filter to it.
    const next = category === active ? null : category;

    if (!isControlled) {
      setInternalActive(next);
    }
    onChange?.(next);
  };

  return (
    <nav className="bg-black">
      <ul
        className="flex list-none gap-1.5 overflow-x-auto whitespace-nowrap px-4 py-0
                   [-webkit-overflow-scrolling:touch] [scrollbar-width:none]
                   [&::-webkit-scrollbar]:hidden"
      >
        {categories.map((category) => {
          const isActive = category === active;
          return (
            <li key={category} className="shrink-0">
              <button
                type="button"
                onClick={() => handleClick(category)}
                className={`shrink-0 whitespace-nowrap rounded-md border-2 px-4 py-2
                            text-sm text-white transition-colors duration-150 ease-in-out
                            ${
                              isActive
                                ? 'border-white bg-[#1F1F1F]'
                                : 'border-transparent bg-[#1F1F1F]'
                            }`}
              >
                {category}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
