import EventCard, { type EventCardData } from "./EventCard";

/**
 * Responsive grid for the home feed: 1 column on phones, 2 on tablets
 * (from `md`, 768px), 3 on large screens (from `lg`, 1024px) — matching
 * the breakpoints already used for SiteHeader (phone vs. tablet/desktop
 * header switches at `md`).
 *
 * Each card fills its grid cell (`w-full` inside EventCard) rather than
 * the raw HTML's standalone 98% width — that 98%/centering was for a
 * single card sitting alone in a demo page; here the grid's gap already
 * provides spacing, so the card should fill its cell edge-to-edge.
 *
 * Server Component — no interactivity of its own, just layout. Each
 * EventCard inside still has its own Client Component islands.
 */

type EventCardGridProps = {
  events: EventCardData[];
};

export default function EventCardGrid({ events }: EventCardGridProps) {
  return (
    <div className="mx-auto grid w-full max-w-[1400px] grid-cols-1 gap-[13px] px-3 py-4 md:grid-cols-2 lg:grid-cols-3 lg:px-6">
      {events.map((event) => (
        <EventCard key={event.id} event={event} />
      ))}
    </div>
  );
}
