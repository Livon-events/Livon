import Link from "next/link";
import Image from "next/image";
import { MapPin } from "lucide-react";
import { getPriceLabel } from "@/lib/format/eventCard";
import EventCardHead from "./EventCardHead";
import EventCardActions from "./EventCardActions";
import EventCardBackground from "./EventCardBackground";

/**
 * Home feed event card. Converted from
 * raw_html_and_css/phone_eventCard/phone_card.html + phone_card.css, with
 * display rules from docs/fr/home-feed-event-card.md (countdown/time
 * thresholds, price/title/location formatting, tap-target isolation).
 *
 * Server Component: the countdown/time chips and the two footer buttons
 * are isolated into their own Client Component islands (EventCardHead,
 * EventCardActions) — everything else here (poster, title, price,
 * location, host) is static per render and stays server-rendered.
 *
 * Card-wide tap navigates to the event page, EXCEPT the Peek, Interested,
 * and Share controls (per FR). Implementation: the whole card is a
 * Next.js <Link>, and those three buttons live inside Client Components
 * that call preventDefault()+stopPropagation() on click to swallow the
 * Link's navigation before doing their own (stubbed) thing. Nesting
 * buttons inside an <a> isn't pixel-spec-pure HTML, but it's the standard
 * pattern for "whole card navigates, except these controls" and works
 * reliably across browsers.
 *
 * NOT WIRED UP YET (conversion pass only):
 * - Cover image placeholder is a plain colored block, not a designed
 *   placeholder image — swap in a real one when you have it. Once real
 *   Supabase Storage URLs are used for `coverImageUrl`, add that
 *   hostname to `images.remotePatterns` in next.config.
 * - Interested/Share/Peek are UI stubs owned by EventCardActions.tsx and
 *   EventCardHead.tsx directly (each just receives `event.id`) — see
 *   those files for what's deferred and to which FR docs. There's no
 *   callback prop threaded through here, because this is a Server
 *   Component and can't hand event-handler functions down to its Client
 *   Component children.
 */

export type EventCardData = {
  id: string;
  title: string;
  price: number; // numeric, never null, schema default 0
  venueName: string;
  area: string;
  hostUsername: string;
  coverImageUrl: string | null;
  startsAt: string; // ISO timestamp
  endsAt: string | null; // ISO timestamp, or null (8hr fallback applies)
  peekConnectionsCount: number;
};

type EventCardProps = {
  event: EventCardData;
};

export default function EventCard({ event }: EventCardProps) {
  return (
    <Link
      href={`/events/${event.id}`}
      id={`eventCard-${event.id}`}
      className="relative flex h-full w-full flex-col text-white"
    >
      <EventCardBackground eventId={event.id} />

      <EventCardHead
        startsAt={event.startsAt}
        endsAt={event.endsAt}
        peekConnectionsCount={event.peekConnectionsCount}
        eventId={event.id}
      />

      <div className="relative z-10 m-[3px] mt-[5px] flex flex-1 flex-col overflow-hidden rounded-[10px] bg-black">
        <div className="relative m-[4px] aspect-[1200/630] w-[calc(100%-8px)] shrink-0 overflow-hidden rounded-[9px] bg-[#CC00AA]">
          {event.coverImageUrl && (
            <Image
              src={event.coverImageUrl}
              alt={event.title}
              fill
              sizes="(min-width: 1024px) 33vw, (min-width: 768px) 50vw, 100vw"
              className="object-cover"
            />
          )}
        </div>

        <div className="flex flex-1 flex-col p-[6px] text-white">
          <h2 className="mb-[12px] line-clamp-2 min-h-[2.75em] text-lg font-bold leading-snug">
            {event.title}
          </h2>
          <h3 className="text-base font-bold">{getPriceLabel(event.price)}</h3>
          <div className="my-1 flex items-center gap-1 text-[14px] text-[#B1B0B0]">
            <p className="truncate">
              <span>{event.venueName}</span>, <span>{event.area}</span>
            </p>
            <MapPin className="h-[20px] w-[20px] shrink-0" strokeWidth={2} />
          </div>
          <p className="text-[14px]">
            Hosted by{" "}
            <span className="font-bold text-[#FFEA00]">{event.hostUsername}</span>
          </p>
        </div>

        <EventCardActions eventId={event.id} />
      </div>
    </Link>
  );
}
