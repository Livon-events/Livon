"use client";

import { useEffect, useState } from "react";
import { getCountdownLabel, getTimeOrLiveLabel } from "@/lib/format/eventCard";

/**
 * The event card's top row: countdown chip, Peek trigger (with connections
 * badge), and time/"Live" chip. Client Component for two reasons:
 *
 * 1. The countdown and time labels must be computed against the *viewer's
 *    device* clock/timezone (per docs/fr/home-feed-event-card.md), not the
 *    server's. Computing them during SSR would use the server's clock —
 *    if that differs from the viewer's local calendar day, React would
 *    throw a hydration mismatch. So the actual computation only runs
 *    after mount (see the empty-until-mounted render below); the brief
 *    blank chip on first paint is the intentional trade-off for
 *    timezone-correct output rather than a wrong-but-consistent value.
 * The Peek button is an interactive control that must NOT trigger the
 *    card-wide navigation Link it sits inside (see EventCard.tsx) — it
 *    needs its own click handler with stopPropagation/preventDefault.
 *
 * Peek's actual behavior (opening the peek list) is governed by
 * docs/fr/peek.md and is NOT implemented here — this is a conversion
 * pass. `eventId` is threaded through so the real implementation has
 * what it needs to open the right peek list; the click handler itself is
 * a stub.
 *
 * Note on why there's no `onPeek` callback prop: EventCard (this
 * component's parent) is a Server Component, and Server Components can't
 * create and hand down event-handler functions to Client Components —
 * there's no live client closure to pass at that point in the tree. Once
 * Peek is wired up, call its logic directly from here (e.g. open a modal
 * via local state, or call a client-safe helper), not via a prop
 * threaded through EventCard.
 */

type EventCardHeadProps = {
  startsAt: string; // ISO timestamp
  endsAt: string | null; // ISO timestamp, or null (8hr fallback applies)
  peekConnectionsCount: number;
  eventId: string;
};

export default function EventCardHead({
  startsAt,
  endsAt,
  peekConnectionsCount,
  eventId,
}: EventCardHeadProps) {
  const [labels, setLabels] = useState<{ countdown: string; time: string } | null>(
    null
  );

  useEffect(() => {
    const now = new Date();
    const starts = new Date(startsAt);
    const ends = endsAt ? new Date(endsAt) : null;
    setLabels({
      countdown: getCountdownLabel(starts, now),
      time: getTimeOrLiveLabel(starts, ends, now),
    });
  }, [startsAt, endsAt]);

  const handlePeekClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // TODO: open the Peek flow for `eventId` per docs/fr/peek.md.
  };

  return (
    <div className="relative z-10 flex h-[46px] w-full flex-row items-center gap-[13px] p-[5px]">
      <div className="flex h-full flex-1 items-center justify-center rounded-[7px] bg-black text-[13px] font-bold text-white">
        {labels?.countdown ?? "\u00A0"}
      </div>

      <button
        type="button"
        id={`peekBtn-${eventId}`}
        onClick={handlePeekClick}
        data-event-id={eventId}
        className="relative flex h-full flex-1 items-center justify-center rounded-[7px] border-[3px] border-[#FFEA00] bg-black text-[14px] font-bold text-[#FFEA00] transition-transform active:scale-95"
      >
        <span>Peek</span>
        <span className="absolute right-[6px] top-1/2 flex h-4 w-4 -translate-y-1/2 items-center justify-center rounded-full bg-[#FFEA00] text-[10px] font-black leading-none text-black">
          {peekConnectionsCount}
        </span>
      </button>

      <div className="flex h-full flex-1 items-center justify-center rounded-[7px] bg-black text-[13px] font-bold text-white">
        {labels?.time ?? "\u00A0"}
      </div>
    </div>
  );
}
