"use client";

import { useState } from "react";
import { Share2 } from "lucide-react";

/**
 * The event card's footer: Interested toggle + Share button. Client
 * Component because both need onClick handlers, and both must stop the
 * click from bubbling up to the card-wide navigation Link they sit
 * inside (see EventCard.tsx).
 *
 * NOT WIRED UP YET (conversion pass only):
 * - Interested is local optimistic UI state only — no mutation call, no
 *   persistence. Real behavior (and its privacy rules — visible/private
 *   RSVPs) is governed by docs/fr/going-rsvp-privacy.md; wire the click
 *   handler below to a `lib/mutations/` call and seed `initialInterested`
 *   from the real per-user RSVP state once that read path exists.
 * - Share is a stub. Real behavior is governed by
 *   docs/fr/invite-links.md (generating/copying an invite link) — wire
 *   the click handler below to that flow later.
 *
 * Note on why there's no `onToggleInterested`/`onShare` callback prop:
 * EventCard (this component's parent) is a Server Component, and Server
 * Components can't create and hand down event-handler functions to
 * Client Components — there's no live client closure to pass at that
 * point in the tree. `eventId` is threaded through instead so the real
 * mutation calls (made directly from here once wired) have what they
 * need.
 */

type EventCardActionsProps = {
  eventId: string;
  initialInterested?: boolean;
};

export default function EventCardActions({
  eventId,
  initialInterested = false,
}: EventCardActionsProps) {
  const [interested, setInterested] = useState(initialInterested);

  const handleInterestedClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setInterested((prev) => !prev);
    // TODO: call the toggle-interest mutation for `eventId` here per
    // docs/fr/going-rsvp-privacy.md.
  };

  const handleShareClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    // TODO: trigger the invite-link share flow for `eventId` per
    // docs/fr/invite-links.md.
  };

  return (
    <div className="m-[5px] flex w-[calc(100%-10px)] flex-row items-center gap-[5px]">
      <button
        type="button"
        onClick={handleInterestedClick}
        data-event-id={eventId}
        className={`h-[50px] flex-1 rounded-[6px] border-[3px] text-[1.2rem] font-black transition-all active:scale-[0.96] ${
          interested
            ? "border-[#FFEA00] bg-black text-[#FFEA00]"
            : "border-transparent bg-[#FFEA00] text-black"
        }`}
      >
        Interested
      </button>
      <button
        type="button"
        onClick={handleShareClick}
        data-event-id={eventId}
        aria-label="Share event"
        className="flex h-[50px] shrink-0 basis-1/4 items-center justify-center rounded-[6px] bg-[#FFEA00] text-black transition-transform active:scale-[0.96]"
      >
        <Share2 className="h-5 w-5" strokeWidth={2.5} />
      </button>
    </div>
  );
}
